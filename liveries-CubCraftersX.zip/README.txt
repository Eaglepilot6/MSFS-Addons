Installation: 
1. Extract "liveries-CubCraftersX.zip"
2. Move liveries-CubCraftersX folder to your Flight Simulator "Community" folder
If you used a custom location, it will be under Drive_Letter:\Install_Dir\Community
If you installed in the default, use C:\Users\YOU\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community
3. Restart MSFS

These texture files are for individual use and may not be distributed without author's permission. These textures are freeware, and are not to be used for commercial purposes without author's written consent. 